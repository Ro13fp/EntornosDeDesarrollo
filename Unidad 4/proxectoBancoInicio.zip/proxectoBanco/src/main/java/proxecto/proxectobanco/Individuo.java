package proxecto.proxectobanco;

/**
 *
 * @author profesor
 */
public class Individuo{
    private String nome;
    private String enderezo;
    private String cidade;
    private String provincia;
    private String telefono;
    private String email;

    public Individuo() {
        nome=null;
        enderezo=null;
        cidade=null;
        provincia=null;
        telefono=null;
        email=null;
    }
}
